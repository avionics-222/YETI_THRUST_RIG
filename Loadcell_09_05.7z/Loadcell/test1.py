import time
import statistics
import os
from gpiozero import DigitalInputDevice, DigitalOutputDevice
import sys

# Pin configuration - adjust to match your wiring
DT_PIN = 5    # HX711 Data pin
SCK_PIN = 6   # HX711 Clock pin

# Correct wiring reminder:
# Red wire → E+ (Excitation+)
# Black wire → E- (Excitation-)
# Green wire → A+ (Signal+)
# White wire → A- (Signal-)

class HX711_GPIOZERO:
    def __init__(self, dout_pin=DT_PIN, sck_pin=SCK_PIN):
        """Initialize HX711 using gpiozero instead of RPi.GPIO"""
        try:
            print(f"Initializing HX711 with dout_pin={dout_pin}, sck_pin={sck_pin}")
            self.dout = DigitalInputDevice(dout_pin)
            self.sck = DigitalOutputDevice(sck_pin, initial_value=False)
            print("GPIO pins initialized successfully")
        except Exception as e:
            print(f"Error initializing GPIO: {e}")
            print("Make sure you're running the script with sudo")
            sys.exit(1)

        # Calibration values
        self.offset = 0
        self.scale = 1
        self.last_valid_reading = 0
        
        # Let the HX711 settle
        time.sleep(0.5)
    
    def reset(self):
        """Reset the HX711"""
        self.sck.on()
        time.sleep(0.06)
        self.sck.off()
        time.sleep(0.01)
        print("HX711 reset completed")
    
    def read_raw(self):
        """Read raw 24-bit value from HX711"""
        # Wait for the HX711 to be ready (data pin goes low)
        timeout_start = time.time()
        while self.dout.value == 1:
            if time.time() - timeout_start > 0.5:  # 500ms timeout
                print("HX711 not responding, attempting reset...")
                self.reset()
                # Try again after reset
                timeout_start = time.time()
                while self.dout.value == 1:
                    if time.time() - timeout_start > 0.5:
                        return None  # Still not responding
            time.sleep(0.001)
        
        # Read 24 bits of data
        data = 0
        for _ in range(24):
            self.sck.on()
            # Using shorter delays for Raspberry Pi 5's faster processor
            self.sck.off()
            data = (data << 1) | self.dout.value
        
        # 25th pulse for channel selection (channel A, gain 128)
        self.sck.on()
        self.sck.off()
        
        # Convert 2's complement
        if data & 0x800000:  # Check if signed bit is set
            data = data - 0x1000000
        
        # Ignore obviously invalid readings
        if data == 0 or data == -1:
            return None
            
        return data
    
    def read_average(self, num_readings=10, max_retries=20):
        """Take multiple readings and return filtered average"""
        readings = []
        retries = 0
        
        while len(readings) < num_readings and retries < max_retries:
            reading = self.read_raw()
            if reading is not None:
                readings.append(reading)
            else:
                retries += 1
                time.sleep(0.01)
        
        if not readings:
            return self.last_valid_reading if self.last_valid_reading else 0
        
        # Filter outliers and return average
        if len(readings) > 4:
            # Sort the readings
            readings.sort()
            # Remove the highest and lowest values (20% of readings)
            num_to_remove = max(1, int(len(readings) * 0.2))
            readings = readings[num_to_remove:-num_to_remove]
        
        # Use median for better noise rejection
        result = statistics.median(readings)
        self.last_valid_reading = result
        return result
    
    def tare(self, num_readings=20):
        """Set the current weight as zero"""
        print("Taring... Please wait and keep scale empty.")
        self.offset = self.read_average(num_readings)
        print(f"Tare complete. Zero offset: {self.offset}")
        return self.offset
    
    def set_scale(self, scale_factor):
        """Set the scale factor for converting raw values to weight units"""
        self.scale = scale_factor
        print(f"Scale factor set to: {scale_factor}")
    
    def get_weight(self, num_readings=10):
        """Get weight in calibrated units"""
        average = self.read_average(num_readings)
        # Prevent division by zero
        if self.scale == 0:
            self.scale = 1
            print("Warning: Scale factor was zero. Set to 1 to prevent division by zero.")
        return (average - self.offset) / self.scale
    
    def calibrate_with_known_weight(self, known_weight_kg):
        """Calibrate using a known weight"""
        print("Remove all weight from the scale and press Enter")
        input()
        
        # Tare scale
        self.tare()
        print("Zero calibration completed.")
        
        print(f"Place the known weight of {known_weight_kg}kg on the scale and press Enter")
        input()
        
        # Take readings with the known weight
        print("Reading weight... Please wait.")
        raw_value = self.read_average(20)
        
        # Calculate and set scale factor
        if known_weight_kg == 0:
            print("Error: Known weight cannot be zero.")
            return 0
            
        self.scale = (raw_value - self.offset) / known_weight_kg
        print(f"Calibration complete. Scale factor: {self.scale}")
        
        return self.scale
    
    def cleanup(self):
        """Clean up resources (gpiozero handles this automatically)"""
        # gpiozero handles cleanup automatically
        print("GPIO cleanup complete")


def main():
    print("CZI-601AC 120kg Load Cell with HX711 (Using gpiozero for Raspberry Pi 5)")
    print("-----------------------------------------------------------")
    print(f"Current Date and Time: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Current User: {os.environ.get('USER', 'Unknown')}")
    print("-----------------------------------------------------------")
    
    hx = None
    try:
        # Initialize HX711
        hx = HX711_GPIOZERO()
        
        print("\nOptions:")
        print("1. Start reading weights")
        print("2. Run calibration")
        choice = input("Select option (1/2): ")
        
        if choice == '2':
            # Run calibration
            known_weight = float(input("Enter the weight of your calibration object in kg: "))
            scale_factor = hx.calibrate_with_known_weight(known_weight)
            print(f"Use this scale factor in your code: {scale_factor}")
        else:
            # Ask for scale factor or use default
            use_default = input("Do you have a calibration factor? (y/n): ")
            if use_default.lower() == 'y':
                factor = float(input("Enter your calibration factor: "))
                hx.set_scale(factor)
            else:
                print("Using default calibration. Readings may not be accurate.")
                print("Consider running calibration for accurate measurements.")
                # Default calibration for CZI-601AC
                hx.set_scale(25.6)  # Using the value from your provided code
                print("Using calibration factor from reference code: 25.6")
            
            # Tare the scale
            print("Ensure the scale is empty, then press Enter to tare")
            input()
            hx.tare()
            print("Tare complete. Starting weight measurements...")
            
            failure_count = 0
            # Continuous weight reading
            try:
                print("\nPress Ctrl+C to stop reading")
                print("----------------------------")
                while True:
                    try:
                        weight = hx.get_weight(num_readings=3)  # Fewer readings for faster response
                        print(f"Weight: {weight:.2f} kg", end='\r')
                        failure_count = 0  # Reset on success
                    except Exception as e:
                        print(f"\nError reading weight: {e}")
                        failure_count += 1
                        if failure_count >= 3:
                            print("Resetting HX711...")
                            hx.reset()
                            failure_count = 0
                    
                    time.sleep(0.25)  # Update 4 times per second
            except KeyboardInterrupt:
                print("\nStopped by user")
    
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Clean up
        if hx:
            hx.cleanup()


if __name__ == "__main__":
    main()
